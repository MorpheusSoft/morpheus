@echo off
sc stop "NeoAgentSync" >nul 2>&1
timeout /t 1 /nobreak >nul
sc delete "NeoAgentSync"
sc stop "NEO" >nul 2>&1
timeout /t 1 /nobreak >nul
sc delete "NEO"
sc stop "MorpheusSyncAgent" >nul 2>&1
timeout /t 1 /nobreak >nul
sc delete "MorpheusSyncAgent"
echo Servicio NEO Agent Sync desinstalado exitosamente.
pause

@echo off
net stop "NeoAgentSync"
pause

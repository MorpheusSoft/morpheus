@echo off
net start "NeoAgentSync"
pause

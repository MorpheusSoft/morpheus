@echo off
start "" "%~dp0MorpheusConfigurador.exe"
